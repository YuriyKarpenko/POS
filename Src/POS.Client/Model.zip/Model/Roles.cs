﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POS.Data.Model
{
	public enum Role
	{
		None,
		Administratior,
		Direktor,
		Manager
	}
}